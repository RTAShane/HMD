window.onload = (event) => {


	if ($('.gallery__wrapper').length) {
		$('.gallery__wrapper').imagesLoaded( function() {
		  $('.gallery__wrapper .gallery__grid').isotope({
			  itemSelector: '.elem__gallery',
			  percentPosition: true,
			  masonry: {
			    columnWidth:".size",
			    gutter:0
			  }
			})
		});
		
	}
		
	if ($('.product__grid .frame__grid').length) {
		$('.product__grid .grid__wrapper .elem').on('click' ,function(e){
			e.preventDefault();
			$('.modal__frame').fadeIn(300);
			$('body,html').css("overflow-y" ,"hidden");
			$('.modal__frame .element__container').css("display" ,"none");
			$('.modal__frame .element__container[data-frame='+ $(this).attr("data-frame") +']').fadeIn(300);
		});
		$('.modal__frame .close__button').on("click" ,function(e){
			e.preventDefault();
			$(this).closest(".modal__frame").fadeOut(300);
			$('body,html').css("overflow-y" , "initial");
		});
	}

	$('.door__grid .elem').on("click" ,function(e){
		e.preventDefault();
		$('.modal__door').fadeIn(300);
		$('body,html').css("overflow-y" ,"hidden");
		$('.modal__door .element__door').css("display" ,"none");
		$('.modal__door .element__door[data-door='+ $(this).attr("data-door") +']').fadeIn(300);
	});


	$('.modal__door .close__door').on('click' ,function(e){
		e.preventDefault();
		$(this).closest('.modal__door').fadeOut(300);
		$('body,html').css("overflow-y" ,"initial");
	});
	

	$(document).click(function(event) { 
	  var $target = $(event.target);
	  if(!$target.closest('.modal__box').length && !$target.closest('.door__grid .elem').length && !$target.closest('.frame__grid .elem').length) {
	  	$('.modal__door').fadeOut(300);
	  	$('.modal__frame').fadeOut(300);
	  	if ((!$target.closest('.menu__button').length)) {
	  		$('body,html').css('overflow-y' ,"initial");
	  	}
	  }        
	});

	document.querySelector('.menu__button>a').addEventListener("click" , function(){
		if (this.classList.contains("active")) {
			this.classList.remove("active");
			let menuBody = document.querySelectorAll("body,html");
			menuBody.forEach((elem) => {
				elem.style.overflowY = "initial";
			});
			document.querySelector('.menu__wrapper').style.top = "-100%";
		} else{
			this.classList.add("active");
			let menuBody = document.querySelectorAll("body,html");
			menuBody.forEach((elem) => {
				elem.style.overflowY = "hidden";
			});
			document.querySelector('.menu__wrapper').style.top = "0px";
		}
	});

};